<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Ejercicio 4</title>
</head>
<body>
	<form action="resultado_ejercicio4.php" method="post">
	<label for="textNombre">Usuario:</label><input type="text" id="textUsuario" name="user"/><br>
	<label for="textApellidos">Contraseña:</label><input type="password" id="textContrasenia" name="password"/><br>
	<input type="submit" value="Iniciar sesión" />
	</form>
</body>
</html>