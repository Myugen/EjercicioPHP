<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Ejercicio 1</title>
</head>
<body>
	<form action="error_ejercicio1.php" method="post">
	<label for="textBoxNombre"><strong>(*)Nombre:</strong></label><input type="text" name="nombre" id="textBoxNombre" /><br>
	<label for="textBoxNombre"><strong>(*)DNI:</strong></label><input type="text" name="dni" id="textBoxDNI" /><br>
	<label for="textBoxNombre"><strong>(*)Sueldo:</strong></label><input type="text" name="sueldo" id="textSueldo" /><br>
	<h3>Los campos marcados con (*) son obligatorios</h3><br>
	<input type="submit" value="Ingresar datos" />
	</form>
</body>
</html>