<?php
// El germen
$styleCheese = "";
if (!isset($_COOKIE['sitestyle'])) { 
	$styleCheese = "insecto";
} 
else { 
	$styleCheese = $_COOKIE['sitestyle']; 
}
?>